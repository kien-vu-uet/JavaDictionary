package com.project1.controllers;

import com.project1.Main;
import com.project1.sources.SQLiteJDBC;
import com.project1.sources.Word;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Objects;

public class NewWordAdditionController {
    @FXML
    private Button returnHomeButton;

    @FXML
    private Button addMyWordButton;

    @FXML
    private TextArea wordArea;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Label messageLabel;

    @FXML
    private Stage stage;

    @FXML
    private void returnHomeButtonOnClick() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("fxml/Home.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 720, 480);
            this.stage = Main.getMainStage();
            stage.setTitle("My Dictionary");
            stage.getIcons().add(new Image(Objects.requireNonNull(Main.class.getResourceAsStream("icon/icon.png"))));
            stage.setScene(scene);
            this.stage.show();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void addMyWordButtonOnClick() throws Exception {
        String word = wordArea.getText();
        String des = descriptionArea.getText();
        if (word.equals("")) {
            messageLabel.setText("'Word' cannot be null");
            return;
        }
        if (des.equals("")) {
            messageLabel.setText("'Description' cannot be null");
            return;
        }
        ArrayList<Word> wordList;
        wordList = SQLiteJDBC.queryLookup(word);
        for (Word value : wordList) {
            if (value.getTarget().equals(word) && value.getExplain().equals(des)) {
                messageLabel.setText("A similar word already exists");
                return;
            }
        }
        SQLiteJDBC.insertToDatabase(new Word(word, des, ""));
        messageLabel.setText("Successfully");
        stage = Main.getMainStage();
        stage.show();
        //System.out.println(word + " " + des + " " + pro);
    }
}
