package com.project1.controllers;

import com.project1.sources.SQLiteJDBC;
import com.project1.sources.Word;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.util.ArrayList;

public class ModifyWordController {
    @FXML
    private Button saveButton;

    @FXML
    private TextArea wordArea;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Button loadButton;

    @FXML
    private Label messageLabel;

    @FXML
    private Stage stage;

    private static ArrayList<Word> wordList;

    @FXML
    private void saveButtonOnClick() throws Exception {
        try {
            String word = wordArea.getText();
            String des = descriptionArea.getText();
            if (word.equals("") || des.equals("")) {
                messageLabel.setText("Click 'Load' to load your work");
                return;
            } else { messageLabel.setText(""); }
            if (des.charAt(des.length() - 1) != '\n') { des += '\n'; }
            ArrayList<Word> modifiedWord = new ArrayList<>();
            while (des.indexOf('\n') != -1) {
                String description = des.substring(0, des.indexOf("\n"));
                des = removeSubString(des);
                if (des.contains(description)) { continue; }
                modifiedWord.add(new Word(word, description, ""));
            }
            int p = Math.min(modifiedWord.size(), wordList.size());
            for (int i = 0; i < p; ++i) {
                Word w = modifiedWord.get(i);
                w.setId(wordList.get(i).getId());
                SQLiteJDBC.modifyDatabase(w);
            }
            if (p < modifiedWord.size()) {
                for (int i = p; i < modifiedWord.size(); ++i) {
                    SQLiteJDBC.insertToDatabase(modifiedWord.get(i));
                }
            } else if (p < wordList.size()) {
                for (int i = p; i < wordList.size(); ++i) {
                    SQLiteJDBC.deleteRowWithKey(wordList.get(i));
                }
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    @FXML
    public void loadButtonOnClick() throws Exception {
        try {
            wordList = DictionaryController.getWordlist();
            String wordTarget = wordList.get(0).getTarget();
            wordArea.setText(wordTarget);
            String wordDes = "";
            String wordPronounce = "";
            for (Word value : wordList) {
                if (!value.getPronounce().equals("")) {
                    wordPronounce += value.getPronounce() + "\n";
                }
                if (!value.getExplain().equals("")) {
                    wordDes += value.getExplain() + "\n";
                }
            }
            descriptionArea.setText(wordDes);
            stage = DictionaryController.getModifyStage();
            stage.show();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    private String removeSubString(String s) {
        StringBuilder sb = new StringBuilder(s);
        sb.replace(0, s.indexOf("\n") + 1, "");
        return sb.toString();
    }
}
