package com.project1.sources;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class SQLiteJDBC {

    public static void insertToDatabase(Word w) throws IOException {
        try {
            Connection connection = null;
            Statement statement = null;
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            String command = "INSERT INTO EngToVie (word,description,pronounce) " +
                    "VALUES ('" + w.getTarget() +"','" + w.getExplain() + "','" +
                    w.getPronounce() + "');";
            statement.executeUpdate(command);
            statement.close();
            connection.commit();
            connection.close();
        } catch (Exception e ) {
            System.err.println( e.getClass().getName() + ": " + e.getMessage() );
        }
    }
    /*
    public static String queryAllWordRecorded() {
         Connection c = null;
         Statement stmt = null;
         String res = "";
         try {
              Class.forName("org.sqlite.JDBC");
              c = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
              c.setAutoCommit(false);
              stmt = c.createStatement();
              ResultSet rs = stmt.executeQuery("SELECT id, word, description FROM EngToVie;");
              res = res + String.format("%8s | %-50s | %-5s %n", "No", "English", "Vietnamese");

              while (rs.next()) {
                 int id = rs.getInt("id");
                 String w = rs.getString("word");
                 String d = rs.getString("description");
                 res = res + String.format("%8d | %-50s | %-5s %n", id, w, d);
              }
              rs.close();
              stmt.close();
              c.close();
           } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
           }
               // System.out.println("Operation Show All done successfully");
         return  res;
    }
    */
    public static ArrayList<Word> queryLookup(String word) throws IOException {
        try {
            ArrayList<Word> res = new ArrayList<Word>();
            Connection connection = null;
            Statement statement = null;
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            if (connection == null) {
                System.out.println("No connect");
            }
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM EngToVie Where word ='" + word + "';" );
            while (rs.next()) {
                int id = rs.getInt("id");
                String w = rs.getString("word");
                String p = rs.getString("pronounce");
                String d = rs.getString("description");
                res.add(new Word(id, w, d, p));
            }
            rs.close();
            statement.close();
            connection.close();
            return res;
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            //System.exit(0);
        }
        return new ArrayList<Word>();
    }

    public static String patternSearch(String pat) throws IOException {
        try {
            String res = "";
            Connection connection = null;
            Statement statement = null;
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            if (connection == null) {
                System.out.println("No connect");
            }
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM EngToVie Where word LIKE '" + pat + "%';");
            while (rs.next()) {
                String w = rs.getString("word");
                res += w + "\n";
            }
            rs.close();
            statement.close();
            connection.close();
            return res;
        } catch (Exception e) {
            System.err.println("No result found");
        }
        return "";
    }

    public static void DatabaseToTextFile() throws IOException {
        Connection c = null;
        Statement stmt = null;
        try {
            FileWriter myWriter = new FileWriter("ExportedFromJava.txt");
            // myWriter.write("This is a sample test of Duy!");
            Class.forName("org.sqlite.JDBC");
            c = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            c.setAutoCommit(false);
            stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id, word, description FROM EngToVie;");
            myWriter.write(String.format("%8s | %-50s | %-5s %n", "No", "English", "Vietnamese"));

            while (rs.next()) {
                int id = rs.getInt("id");
                String w = rs.getString("word");
                String d = rs.getString("description");
                myWriter.write(String.format("%8d | %-50s | %-5s %n", id, w, d));
            }
            rs.close();
            stmt.close();
            c.close();
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }

    public static void modifyDatabase(Word word) throws IOException {
//        @SuppressWarnings("unused")
//        String catchEnter = sc.nextLine();
        try {
            Connection connection = null;
            Statement statement = null;
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            statement.executeUpdate("UPDATE EngToVie SET word ='" + word.getTarget() + "' WHERE id ='" + word.getId() + "';");
            statement.executeUpdate("UPDATE EngToVie SET description ='" + word.getExplain() + "' WHERE id ='" + word.getId() + "';");
            statement.executeUpdate("UPDATE EngToVie SET pronounce ='" + word.getPronounce() + "' WHERE id ='" + word.getId() + "';");
            statement.close();
            connection.commit();
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
        System.out.println("Edit done Successful");
    }

    public static void deleteRowWithKey(Word word) throws IOException {
        try {
            Connection connection = null;
            Statement statement = null;
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:dictionary.db");
            connection.setAutoCommit(false);
            statement = connection.createStatement();
            statement.executeUpdate("DELETE FROM EngToVie WHERE id = '" + word.getId() + "';");
            statement.close();
            connection.commit();
            connection.close();
        } catch (Exception e) {
            System.err.println("No Word Found, Escaped Method!");
        }
    }
}
