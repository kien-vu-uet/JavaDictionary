package com.project1.controllers;

import com.project1.Main;
import com.project1.sources.SQLiteJDBC;
import com.project1.sources.TextToSpeech;
import com.project1.sources.Word;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Objects;

public class DictionaryController {
    @FXML
    private Button returnHomeButton;

    @FXML
    private Button searchButton;

    @FXML
    private TextField wordTypingBar;

    @FXML
    private TextArea wordArea;

    @FXML
    private Label pronunciationArea;

    @FXML
    private TextArea meaningArea;

    @FXML
    private Button pronounceButton;

    @FXML
    private Label messageArea;

    @FXML
    private Button deleteButton;

    @FXML
    private Button modifyButton;

    @FXML
    private Stage stage;

    @FXML
    private static Stage modifyStage;

    private static ArrayList<Word> wordList = new ArrayList<Word>();

    @FXML
    private void returnHomeButtonOnClick() throws Exception{
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("fxml/Home.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 720, 480);
            this.stage = Main.getMainStage();
            stage.setTitle("My Dictionary");
            stage.getIcons().add(new Image(Objects.requireNonNull(Main.class.getResourceAsStream("icon/icon.png"))));
            stage.setScene(scene);
            this.stage.show();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @FXML
    private void searchButtonOnClick() throws Exception {
        wordArea.setText("");
        pronunciationArea.setText("");
        meaningArea.setText("");
        String text = wordTypingBar.getText();
        if (text.equals("")) {
            messageArea.setText("Nothing to search...");
        } else messageArea.setText("");
        String relatedWord = SQLiteJDBC.patternSearch(text);
        if (!checkNullText(relatedWord)) {
            messageArea.setText("No result found!");
            return;
        } else {
            messageArea.setText(countLine(relatedWord));
            wordArea.setText(relatedWord);//1
            String word = relatedWord.substring(0, relatedWord.indexOf("\n"));
            wordList = SQLiteJDBC.queryLookup(word);
            if (wordList.isEmpty()) {
                messageArea.setText("No result found");
            } else {
                String wordTarget = wordList.get(0).getTarget();
                pronunciationArea.setText(" " + wordTarget);//2
                String wordDes = "";
                for (Word value : wordList) {
                    String d = value.getExplain();
                    String wordPronounce = value.getPronounce();
                    if (!wordDes.contains(d)) {
                        if (!wordPronounce.equals("")) {
                            wordDes += "/" + wordPronounce + "/ ";
                        }
                        wordDes += d + "\n";
                    }
                }
                meaningArea.setText(wordDes);//3
            }
        }
        this.stage = Main.getMainStage();
        this.stage.show();
    }

    @FXML
    private void pronounceButtonOnClick() {
        if (wordList.isEmpty()) return;
        TextToSpeech.speak(wordList.get(0).getTarget());
    }

    private boolean checkNullText(String text) {
        String a = text.toLowerCase();
        for (int i = 0; i < a.length(); ++i) {
            if (a.charAt(i) >= 'a' && a.charAt(i) <= 'z') {
                return true;
            }
        }
        return false;
    }

    private String countLine(String text) {
        //System.out.print(text);
        int count = 0;
        for (int i = 0; i < text.length(); ++i) {
            if (text.charAt(i) == '\n') {
                ++count;
            }
        }
        String res = "";
        if (count == 1) res = "1 related result found";
        else res = String.valueOf(count) + " related results found";
        return res;
    }

    @FXML
    private void deleteButtonOnclick() throws Exception {
        if (wordList.isEmpty()) {
            return;
        }
        //System.out.println("call to delete word: " + wordList.get(0).getTarget());
        for (Word value : wordList) {
            SQLiteJDBC.deleteRowWithKey(value);
        }
    }

    @FXML
    private void modifyButtonOnclick() throws Exception {
        if (wordList.isEmpty()) {
            return;
        }
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("fxml/ModifyWord.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 720, 480);
            if (modifyStage == null) {
                modifyStage = new Stage();
            }
            modifyStage.setTitle("My Dictionary");
            modifyStage.getIcons().add(new Image(Objects.requireNonNull(Main.class.getResourceAsStream("icon/icon.png"))));
            modifyStage.setScene(scene);
            modifyStage.show();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static Stage getModifyStage() {
        return modifyStage;
    }

    public static ArrayList<Word> getWordlist() {
        return wordList;
    }
}
